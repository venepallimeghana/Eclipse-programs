package first;
import java.util.*;
public class linklist {
public static void main(String[] args)
{
	LinkedList II=new LinkedList();
	LinkedList II1=new LinkedList();
	II1.add(100); II1.add(200);  II1.add(300);  II1.add(400);
	II.add(10);  II.add(40);   II.add(20);   II.add(80);  II.add(90);   II.add(50); 
	System.out.println(II1);
	System.out.println(II);
	II.addFirst(100);
	System.out.println(II);
	II.addFirst(200);
	System.out.println(II);
	II.removeFirst();
	II.removeLast();
	System.out.println(II);
	System.out.println(II.getFirst());
	System.out.println(II.getLast());
	II.addAll(II1);
	System.out.println(II);
}


}

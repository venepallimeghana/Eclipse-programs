package first;

public class Encapsulation {
private int empno;
private String name,address;
private float salary;
public int getEmpno() {
return empno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public float getSalary() {
	return salary;
}
public void setSalary(float salary) {
	this.salary = salary;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
}

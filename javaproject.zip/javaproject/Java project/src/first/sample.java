package first;

public class sample extends Thread{
	public void run()
	{
		try
		{
			for(int i=1;i<10;i++)
			{
				System.out.println(i);
				sleep(1000);}}
		catch(Exception ae)
		{ae.printStackTrace();}}	
	public static void main(String[] args) {
		sample ob=new sample();
		sample ob1=new sample();
		sample ob2=new sample();
		ob.start();ob1.start();ob2.start();
	}}
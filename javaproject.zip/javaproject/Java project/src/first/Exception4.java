package first;

import java.util.Scanner;

public class Exception4 
{
public static void main(String[] args) throws Exception
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter your age");
	int age=ob.nextInt();
	if (age>18)
		System.out.println("Eligible to vote");
	else
		throw new Exception("You are not eligible to vote");
}
}

package first;
import java.io.*;
import java.util.*;
class a
{
public static void main(String args[])
{	Scanner ob=new Scanner(System.in);
	System.out.println("enter the file name");
String fname=ob.next();
File f=new File(fname);
System.out.println("file name:"+f.getName());
System.out.println("file path:"+f.getPath());
System.out.println("file path:"+f.getAbsolutePath());
System.out.println("file exists:"+f.exists());
if(f.exists()){
System.out.println("file can write:"+f.canWrite());
System.out.println("file can read:"+f.canRead());
System.out.println("file type:"+f.isDirectory());
System.out.println("file length:"+f.length());
}}}
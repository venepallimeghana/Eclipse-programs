package first;

public class string {
public static void main(String[] args)
{
	String a1="apple";
	String a2="apple";
	String a3=new String("apple");
	String a4=new String("apple");
	if(a1==a2)
		System.out.println("true");
	else
		System.out.println("false");
	if(a1==a3)
		System.out.println("true");
	else
		System.out.println("false");
	if(a1.equals(a3))
		System.out.println("true");
	else
		System.out.println("false");
}
}

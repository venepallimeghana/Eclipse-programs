package first;

public class Employee {
	private int empno;
	private String name,design;
	private Address add;
	public Employee(int empno, String name, String design, Address add)
	{
		this.empno = empno;
		this.name = name;
		this.design = design;
		this.add = add;
	}

	void display()
	{
		System.out.println("empno:"+empno+" name :"+name+" designation :"+design+"Address :"+add);
		}}

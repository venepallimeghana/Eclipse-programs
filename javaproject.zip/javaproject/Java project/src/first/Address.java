package first;

public class Address 
{
private int buildno,roadno;
private String sname,city;
public Address(int buildno, int roadno, String sname, String city) {
	this.buildno = buildno;
	this.roadno = roadno;
	this.sname = sname;
	this.city = city;
}
@Override
public String toString() {
	return "buildno=" + buildno + ", roadno=" + roadno + ", sname=" + sname + ", city=" + city ;
}


}

package first;
import java.util.*;
public class Collectionsorting {
	public static void main(String[] args)
	{
	ArrayList<String>al=new ArrayList<String>();
	al.add("Harsha");
	al.add("friends");
	al.add("is");
	al.add("superb");
	Collections.sort(al);
	System.out.println(al);
	}
}

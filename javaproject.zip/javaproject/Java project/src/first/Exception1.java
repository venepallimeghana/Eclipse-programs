package first;

import java.util.Scanner;

public class Exception1
{
public static void main(String[] args)
{
	try
	{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter 2 no");
	int a=ob.nextInt();
	int b=ob.nextInt();
	int c=a/b;
	System.out.println("the result is"+c);
}
	catch(Exception ae)
	{
System.out.println("the error is"+ae);
	}
System.out.println("welcome to exception handling");
}
}

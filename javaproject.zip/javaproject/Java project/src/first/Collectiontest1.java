package first;

import java.util.HashSet;

public class Collectiontest1 {
public static void main(String[] args)
{
	HashSet<Object> ts=new HashSet<Object>();
	Integer a=new Integer(70);
	ts.add(a);
	Integer b=new Integer(80);
	ts.add(b);
	Student ob=new Student();
	ts.add(ob);
	System.out.println(ts);
}
}

package first;

public class a 
{
int empno=100;
String name="ram";
@Override
public String toString() {
	return "a [empno=" + empno + ", name=" + name + "]";
}
}

package first;
public class Test1 {
	public static void main(String[] args) 
	{
	Bank ob=new Bank(101,"hdfc","personal");
	Customer cus=new Customer(31,"Ram","pune","Citi", ob);
	cus.display();
	}}


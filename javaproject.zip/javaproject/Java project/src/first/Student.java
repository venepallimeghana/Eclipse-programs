package first;

public class Student {
int rollno=10;
String name="ram";
String address="pune";
public Student() {
}
public Student(int i, String string, int j) {
	// TODO Auto-generated constructor stub
}}
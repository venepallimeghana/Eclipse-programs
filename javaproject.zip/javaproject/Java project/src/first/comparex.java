package first;

  abstract class comparex implements Comparable<comparex>
 {
	int rollno,age;
	String name;
	comparex(int rollno,String name,int age)
	{
		this.rollno=rollno;
		this.name=name;
		this.age=age;
	}
	public int compareTo(comparex st)
	{
		if(age==st.age)
			return 0;
		else if(age>st.age)
			return 1;
		else
			return -1;
	}

}

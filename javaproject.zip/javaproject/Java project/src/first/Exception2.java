package first;

import java.util.Scanner;

public class Exception2
{
public static void main(String[] args)
{
	try
	{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter 2 no");
	int a=ob.nextInt();
	int b=ob.nextInt();
	int c=a/b;
	System.out.println("the result is"+c);
	try
	{
		int x[]=new int[5];
		System.out.println("enter 5 nos");
		for(int i=0;i<5;i++)
			x[i]=ob.nextInt();
		System.out.println("5 nos are");
		for(int i=0;i<=5;i++)
			
	}
	
	
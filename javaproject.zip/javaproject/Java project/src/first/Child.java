package first;

public class Child extends Inheritance {
float salary;
String design;
public Child(int empno, String name, String address, float salary, String design) {
	super(empno, name, address);
	this.salary = salary;
	this.design = design;
}
void display()
{
	super.display();
	System.out.println("salary:"+salary+"design:"+design);
}
public static void main(String[] args)
{
	Child obj=new Child(101,"ram","pune",4500.54f,"software eng");
	obj.display();
}
}

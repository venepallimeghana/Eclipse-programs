package first;

public class Exception3
{
	public static void main(String[] args) throws Exception
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			Thread.sleep(1000);
		}
	}
}
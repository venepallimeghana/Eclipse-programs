package first;

public class Testemp {
	public static void main(String[] args) 
	{
	Address ob=new Address(101,20,"kharadi","pune");
	Employee emp=new Employee(1001,"sandip","Trainer",ob);
	emp.display();
	}}


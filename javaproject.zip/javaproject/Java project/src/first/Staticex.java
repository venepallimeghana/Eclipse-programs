package first;

public class Staticex 
{
static int a=10;
static void display()
{
	System.out.println("this is a static method");
}
static
{
	System.out.println("this is a static block");
}
public static void main(String[] args)
{
	display();
	System.out.println(a);
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
}

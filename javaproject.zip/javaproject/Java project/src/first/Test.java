package first;

public class Test {
public static void main(String[] args)
{
	Encapsulation obj=new Encapsulation();
	obj.setEmpno(101);
	obj.setName("ram");
	obj.setAddress("pune");
	obj.setSalary(4500.50f);
	System.out.println("empno:"+obj.getEmpno()+"name:"+obj.getName()+"address:"+obj.getAddress());
	System.out.println("salary:"+obj.getSalary());
}
}

package first;

public class StringBuffer {
public StringBuffer(String string) {
		// TODO Auto-generated constructor stub
	}

public static void main(String[] args)
{
	int age=25;
	StringBuffer s=new StringBuffer("She is");
	StringBuffer s1=new StringBuffer("Hello to HP");
	System.out.println("s append="+s.append(age));
	System.out.println("s append="+s.append("years old"));
	System.out.println("entire string="+s.toString());
	System.out.println("length="+s.length());
	System.out.println("capacity="+s.capacity());
	System.out.println("s1="+s1);
	System.out.println("charAt="s1.charAt(1));
	s1.setCharAt

}

private String append(String string) {
	// TODO Auto-generated method stub
	return null;
}

private String append(int age) {
	// TODO Auto-generated method stub
	return null;
}
}

package first;

public class Bank 
{
private int accno;
private String bname,btype;
public Bank(int accno, String bname, String btype) {
	super();
	this.accno = accno;
	this.bname = bname;
	this.btype = btype;
}

@Override
public String toString() {
	return "accno=" + accno + ", bname=" + bname + ", btype=" + btype;
}


}

package first;

public class abc implements Runnable {
	public void run()
	{Thread t=Thread.currentThread();
	String name=t.getName();
		for(int i=0;i<10;i++)
		{
			System.out.println(name+" "+i);
			try {
				Thread.sleep(1000);
			}catch (Exception e)
			{
				e.printStackTrace();}}}}
		class thread3
		{
			public static void main(String[] args)
			{
				abc obj1=new abc();abc obj2=new abc();abc obj3=new abc();
				Thread t1=new Thread(obj1,"ram");
				Thread t2=new Thread(obj2,"raj");
				Thread t3=new Thread(obj3,"ravi");
				t1.start();  t2.start();    t3.start();
			}
		}
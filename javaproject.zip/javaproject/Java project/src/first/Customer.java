package first;

public class Customer {
	private int custid;
	private String name,address;
	private Bank add;
	public Customer(int custid, String name, String address, String bank,Bank add) {
		this.custid = custid;
		this.name = name;
		this.address = address;
	}

	void display()
	{
		System.out.println("custid:"+custid+" name :"+name+" address:"+address+"Bank :"+add);
		}}

package first;

public class Inheritance {
int empno;
String name,address;
public Inheritance(int empno, String name, String address) {
	super();
	this.empno = empno;
	this.name = name;
	this.address = address;
}
void display()
{
	System.out.println("empno:"+empno+"name:"+name+"address:"+address);
}
}

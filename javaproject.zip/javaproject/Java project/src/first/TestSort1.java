package first;
import java.util.*;
public class TestSort1 {
public static void main(String[] args)
{
	ArrayList<comparex>al=new ArrayList<comparex>();
	al.add(new comparex(101,"ram",24));
	al.add(new comparex(103,"raj",27));
	al.add(new comparex(105,"jai",21));
	Collections.sort(al);
	for(comparex st:al)
	{
System.out.println(st.rollno+""+st.name+""+st.age);
	}}
}


public class multi extends thread{
	public void run()
	{
		try
		{
			for(int i=1;i<10;i++)
			{
				System.out.println(i);
				sleep(1000);}}
		catch(Exception ae)
		{ae.printStackTrace();}}
	private void sleep(int i) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		multi ob=new multi();
		multi ob1=new multi();
		multi ob2=new multi();
		ob.start();ob1.start();ob2.start();
			}
	private void start() {
		// TODO Auto-generated method stub
		
	}
		}
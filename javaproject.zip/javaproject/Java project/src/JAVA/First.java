package JAVA;

import java.util.Scanner;

public class First {
int rollno;
String name,address;
int m1,m2,m3,tot,avg,grade;
void input()
{
Scanner ob=new Scanner(System.in);
System.out.println("enter rollno,name,address");
System.out.println("enter 3 subjects marks");
rollno=ob.nextInt();
name=ob.next();
address=ob.next();
m1=ob.nextInt();
m2=ob.nextInt();
m3=ob.nextInt();
tot=m1+m2+m3;
avg=tot/3;
}
void display()
{
System.out.println("the roll no is"+rollno);
System.out.println("the name is"+name);
System.out.println("the address is"+address);
if (avg>=75)
System.out.println("first division");
else if (avg>=55)
System.out.println("second division");
else if(avg>=45)
System.out.println("third division");
else
System.out.println("fail");
}
public static void main(String args[])
{
First obj=new First();
obj.input();
obj.display();
}
}
package JAVA;
public class Casting {
public static void main(String a[])
{
String x=a[0];
String y=a[1];
String z=a[2];
System.out.println(x+""+y+""+z);
}
}

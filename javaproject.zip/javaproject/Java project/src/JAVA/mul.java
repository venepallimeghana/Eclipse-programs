package JAVA;
interface a
{
	 int a=10;//final and static
	 void create();
}
interface b extends a
{
	 void display();
}
interface c
{
	 void list();
}
 class third implements b,c// multiple inheritance
{
	public void create() {
		System.out.println("create");	}

	public void list() {
	System.out.println("list");	}

	public void display() {
		System.out.println("display");	}
	 public static void main(String[] args) {
third ob=new third();
		ob.create();ob.display();ob.list();
		System.out.println("the value of a is "+a);
	}
}


package JAVA;

public class Test12 {
	public static void main(String[] args)
	{
		String [] a= {"1,2,3,4,5,6,7,8,9,10"};
		System.out.println("a[2]="+3);
		
		
}

}

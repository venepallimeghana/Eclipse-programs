package JAVA;
enum Level{LOW,MEDIUM,HIGH}
public class MyClass {
public static void main(String[] args) {
	Level myVar=Level.MEDIUM;
	switch(myVar) {
	case LOW:
		System.out.println("Low level");
		break;
	case MEDIUM:
		System.out.println("Medium level");
	case HIGH:
		break;
	default:
		break;
		
	}
}
}

package JAVA;
import java.util.regex.*;
public class RegexExample {
public static void main(String[] args) {
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}","arun34"));
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}","kkkarun34"));
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}","JGDY34"));
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}","arun$34"));
	System.out.println(Pattern.matches(".s","as"));
	System.out.println(Pattern.matches(".s","mk"));
	System.out.println(Pattern.matches(".s","mst"));
	System.out.println(Pattern.matches(".s","ammms"));
	System.out.println(Pattern.matches("..s","mas"));
	System.out.println(Pattern.matches("[789]{1}[0-9]{9}","7878787878"));
	System.out.println(Pattern.matches("[789][0-9]{9}","7878787878"));
	System.out.println(Pattern.matches("[789]{1}[0-9]{9}","90074773773"));
	System.out.println(Pattern.matches("[789][0-9]{9}","73878787878"));
	System.out.println(Pattern.matches("[789][0-9]{9}","227878787878"));
	System.out.println(Pattern.matches("[789][0-9]{9}","17878787878"));
	System.out.println(Pattern.matches("[789][0-9]{9}","7878787878"));
}
}

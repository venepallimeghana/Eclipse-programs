package JAVA;
import java.util.Scanner;

public class Second
	{
		int empno;
		String name,address;
		void input()
		{
			Scanner ob=new Scanner(System.in);
			System.out.println("enter empno,name and address");
			empno=ob.nextInt();name=ob.next();address=ob.next();
		}
		void display()
		{
		System.out.println("empno :"+empno+"name :"+name+" address :"+address);
		}}
		class Bank extends Second
		{
			int accno;
			String bankname;
			void input()
			{
				super.input();
				Scanner ob=new Scanner(System.in);
				System.out.println("enter accno,bankname");
				accno=ob.nextInt();bankname=ob.next();
			}
			void display()
			{
				super.display();
System.out.println("accno:"+accno+"bankname:"+bankname);
			}
			public static void main(String[] args) 
			{
			Bank ob=new Bank();
			ob.input();
			ob.display();
			}
	}

package JAVA;

public class Constructor
{
Constructor()
{
	System.out.println("this is a default constructor");
}
 Constructor(int a,int b)
{
	System.out.println("the sum is"+(a+b));
}
int sum(int a,int b)
{
	return a+b;
}
float sum(float a,float b)
{
	return a+b;
}
public static void main(String[] args)
{
	Constructor ob=new Constructor();
	Constructor ob1=new Constructor();
	System.out.println("the sum is"+ob.sum(5, 6));
	System.out.println("the sum is"+ob.sum(5.4f, 6.5f));
}
}

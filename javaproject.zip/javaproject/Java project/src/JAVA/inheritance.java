package JAVA;

public class inheritance {

}

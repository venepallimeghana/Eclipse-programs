package JAVA;

import java.util.Scanner;

public class Employe 
{
	int empno;
String name,address;
float salary;
Employe(int empno,String name,String address,float salary)
{
	this.empno=empno;
	this.name=name;
	this.address=address;
	this.salary=salary;
}
void display()
{
	System.out.println("empno:"+empno+""+"name:"+name+""+"address:"+address+""+"salary:"+salary);
}
public static void main(String[] args)
{
Scanner ob=new Scanner(System.in);
System.out.println("enter empno,name,address,salary");
int a=ob.nextInt();String b=ob.next();String c=ob.next();float d=ob.nextFloat();
Employe obj=new Employe(a,b,c,d);
obj.display();
}
}
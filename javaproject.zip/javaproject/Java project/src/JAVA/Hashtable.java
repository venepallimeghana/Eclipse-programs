package JAVA;
import java.util.*;
public class Hashtable {
public static void main(String[] args) {
	HashMap<Integer,String>hm=new HashMap<Integer,String>();
	hm.put(100,"amar");
	hm.put(102, "ram");
	hm.put(101, "vij");
	hm.put(103, "charan");
	for(Map.Entry m:hm.entrySet())
	{
	System.out.println(m.getKey()+""+m.getValue());	
	}
}
}

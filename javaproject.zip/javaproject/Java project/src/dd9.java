
public class dd9 implements Runnable{
 public void run()
{try
{Thread t=Thread.currentThread();
String name=t.getName();
for(int i=0;i<10;i++)
{System.out.println(name+"="+i);
Thread.sleep(500);
if(name.equals("raj")&&(i==4))
{wait();}
if(name.equals("geeta")&&(i==4))
{wait();}
if(name.equals("seeta")&&(i==6))
{System.out.println("raj and geeta thread wakes up..");
notifyAll();
}}}
catch(Exception e) {}}
public static void main(String args[]) throws Exception
{  dd9 obj=new dd9();
Thread t1=new Thread(obj,"raj");
Thread t3=new Thread(obj,"geeta");
Thread t2=new Thread(obj,"seeta");
t1.start();   t2.start();       t3.start();     }}
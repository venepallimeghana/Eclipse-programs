package assignment;
import java.util.*;
public class Customer {
int accno;
String name,branch;
public Customer(String name,String branch) {
	//this.accno=accno;
	this.name=name;
	this.branch=branch;
}
@Override
public String toString() {
	return "Customer [accno=" + accno + ", name=" + name + ", branch=" + branch + "]";
}
}
 class BankDetails
{
	public static void main(String[] args)
	{
		HashMap<Integer,Customer>map=new HashMap<Integer,Customer>();
		Customer c1=new Customer("ram","cit");
		Customer c2=new Customer("raj","city");
		Customer c3=new Customer("ravi","hdfc");
		map.put(100,c1);   map.put(200, c2);   map.put(300, c3);  
Scanner scan=new Scanner(System.in);
System.out.println("enter accountnumber");
int a=scan.nextInt();
Customer c=(Customer)map.get(a);
System.out.println(c);
		}
	}
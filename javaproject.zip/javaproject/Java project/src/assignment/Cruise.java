package assignment;
import java.util.*;
public class Cruise
{
int tno,duration,age;
String name,category;
void charge()
{
	if(category.equals("adult"))
	{
		float total=(1000*duration)+(500*duration);
		System.out.println("ticket charge="+total);
	}
	else if(category.equals("child"))
	{
		float total=(500*duration)+(250*duration);
		System.out.println("ticket charge="+total);
	}
	else
		System.out.println("free for staff");
}
public Cruise(int tno,int duration,int age,String name,String category) 
{
	this.tno=tno;
	this.duration=duration;
	this.age=age;
	this.name=name;
	this.category=category;
}
@Override
public String toString() {
	return "Cruise [tno=" + tno + ", duration=" + duration + ", age=" + age + ", name=" + name + ", category="
			+ category + "]";
}

}
 class Ticketdetails {
	public static void main(String[] args)
	{
		HashMap<Integer,Cruise>map=new HashMap<Integer,Cruise>();
Scanner scan=new Scanner(System.in);
while(true)
{
System.out.println("enter 1 to book ticket and enter 2 to view details");
int a=scan.nextInt();
switch(a)
{
case 1:
	System.out.println("enter ticket no");
	int tno=scan.nextInt();
	System.out.println("enter traveller name");
	String name=scan.next();
	System.out.println("enter the age");
	int age=scan.nextInt();
	System.out.println("enter the category");
	String category=scan.next();
	System.out.println("enter the duration");
	int duration=scan.nextInt();
	Cruise c=new Cruise(tno,duration,age,category,name);
	map.put(tno,c); 
	c.charge();
	System.out.println("ticket booked");
	break;
case 2:
	System.out.println("enter ticket no");
	int no=scan.nextInt();
	Cruise tic=(Cruise)map.get(no);
	System.out.println(tic);
	break;
	}
	}}}
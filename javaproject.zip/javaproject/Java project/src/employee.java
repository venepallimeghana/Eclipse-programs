import java.io.*;
class employee implements Serializable
{
   String name;
   public String address;
   public int SSN;
   public int number;
}
  
package com.dineshonjava.service;

import java.util.List;

import com.dineshonjava.model.Product;

 
public interface ProductService {
	
	public void addProduct(Product product);

	public List<Product> listProductss();
	
	public Product getProduct(int productid);
	
	public void deleteProduct(Product product);
}

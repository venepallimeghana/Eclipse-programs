package com.dineshonjava.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dineshonjava.model.Product;

 
@Repository("ProductDao")
public abstract class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addProduct(Product product) {
		sessionFactory.getCurrentSession().saveOrUpdate(product);
	}

	@SuppressWarnings("unchecked")
	public List<Product> listProductss() {
		return (List<Product>) sessionFactory.getCurrentSession().createCriteria(Product.class).list();
	}

	public Product getProduct(int empid) {
		return (Product) sessionFactory.getCurrentSession().get(Product.class, empid);
	}

	public void deleteProduct(Product product) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM Product WHERE productid = "+product.getProductId()).executeUpdate();
	}

}

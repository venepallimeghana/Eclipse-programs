package com.dineshonjava.dao;

import java.util.List;

import com.dineshonjava.model.Product;

 
public interface ProductDao<Product> {
	
	public void addproduct(Product product);

	public List<Product> listProductss();
	
	public com.dineshonjava.model.Product getProduct(int productid);
	
	public void deleteProduct(Product product);
}

package com.dineshonjava.bean;

 //create table Product(productid number,productname varchar2(30),productdod varchar2(30));
public class ProductBean {
	private Integer id;
	private String name;
	private String dod;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDod() {
		return dod;
	}
	public void setDod(String dod) {
		this.dod = dod;
	}}
	
	
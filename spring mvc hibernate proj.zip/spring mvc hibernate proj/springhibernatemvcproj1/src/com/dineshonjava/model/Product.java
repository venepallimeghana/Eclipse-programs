package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Product")
public class Product implements Serializable{

	//private static final long serialVersionUID = -723583058586873479L;
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "productid")
	private Integer productId;
	
	@Column(name="productname")
	private String productName;
	
	@Column(name="productdod")
	private String productdod;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductdod() {
		return productdod;
	}

	public void setProductdod(String productdod) {
		this.productdod = productdod;
	}}
	
	
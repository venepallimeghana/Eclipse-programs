package com.dineshonjava.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dineshonjava.bean.ProductBean;
import com.dineshonjava.model.Product;
import com.dineshonjava.service.ProductService;

 
@Controller
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute("command")  ProductBean employeeBean, 
			BindingResult result, ProductBean productBean) {
		 Product  product = prepareModel(productBean);
		 productService.addProduct(product);
		return new ModelAndView("redirect:/add.html");
	}

	@RequestMapping(value="/products", method = RequestMethod.GET)
	public ModelAndView listProducts() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("products",  prepareListofBean(productService.listProductss()));
		return new ModelAndView("productsList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addEmployee(@ModelAttribute("command")  ProductBean ProductBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("employees",  prepareListofBean(productService.listProductss()));
		return new ModelAndView("addEmployee", model);
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView editProduct(@ModelAttribute("command")  ProductBean ProductBean,
			BindingResult result) {
		 productService.deleteProduct(prepareModel(ProductBean));
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("product", null);
		model.put("products",  prepareListofBean(productService.listProductss()));
		return new ModelAndView("addProduct", model);
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView deleteEmployee(@ModelAttribute("command")   ProductBean  productBean,
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("product", prepareProductBean(productService.getProduct(productBean.getId())));
		model.put("products",  prepareListofBean(productService.listProductss()));
		return new ModelAndView("addEmployee", model);
	}
	
	private  Product prepareModel( ProductBean productBean){
		 Product  product = new  Product();
		 product.setProductdod(productBean.getDod());
		 product.setProductName(productBean.getName());
		 product.setProductId(productBean.getId());
		 productBean.setId(null);
		return  product;
	}
	
	private List< ProductBean> prepareListofBean(List<Product> Products){
		List< ProductBean> beans = null;
		if(Products != null && ! Products.isEmpty()){
			beans = new ArrayList< ProductBean>();
			 ProductBean bean = null;
			for( Product  product : Products){
				bean = new  ProductBean();
				bean.setName(product.getProductName());
				bean.setId(product.getProductId());
				bean.setDod(product.getProductdod());
				beans.add(bean);
			}
		}
		return beans;
	}
	
	private ProductBean prepareProductBean(Product product){
		 ProductBean bean = new ProductBean();
		bean.setDod( product.getProductdod());
		bean.setName( product.getProductName());
		bean.setId( product.getProductId());
		return bean;
	}
}







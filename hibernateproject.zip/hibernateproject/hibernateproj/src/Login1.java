import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import javax.servlet.annotation.*;
@WebServlet("/Login1")
public class Login1 extends HttpServlet
{	public void service(HttpServletRequest req,HttpServletResponse res)
			throws ServletException,IOException
	{		try
		{	res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			int a=Integer.parseInt(req.getParameter("t1"));
			String b=req.getParameter("t2");
			int c=Integer.parseInt(req.getParameter("t3"));
			String d=req.getParameter("t4");
			String e=req.getParameter("t5");
			Configuration cfg=new Configuration();
			SessionFactory sf=cfg.configure().buildSessionFactory();
			Session ss=sf.openSession();
			pojo pojo=new pojo();
			pojo.setEmpid(a);
			pojo.setName(b);
			pojo.setSalary(c);
			pojo.setAddress(d);
			pojo.setEmail(e);
			Transaction tx=ss.beginTransaction();
			ss.save(pojo);
			tx.commit();
			ss.close();
			res.sendRedirect("success.html");
		}
		catch(Exception ae)
		{		}	}}


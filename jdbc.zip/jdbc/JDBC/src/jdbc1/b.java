package jdbc1;
import java.sql.*;
 class b {
public static void main(String h[]) throws SQLException,ClassNotFoundException {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
	CallableStatement cs=con.prepareCall("{call dept_pro}");
	cs.execute();
	System.out.println("deleted");
}}
package jdbc1;
import java.sql.*;
import java.util.Scanner;
public class third {
public static void main(String[] args) throws Exception
{
	Scanner ob=new Scanner(System.in);
	System.out.println("enter name,address and empno whom you want to update");
	String name=ob.next();
	String address=ob.next();
	int empno=ob.nextInt();
	Class.forName("oracle.jdbc.OracleDriver");
	Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
	PreparedStatement st=con.prepareStatement("update mphasisstudent set name=?,address=? where empno=?");
	st.setString(1, name);
	st.setString(2, address);
	st.setInt(3, empno);
st.execute();
con.commit();
System.out.println("Row inserted");

Statement st1=con.createStatement();
	ResultSet rs=st1.executeQuery("select*from mphasisstudent");
	while(rs.next())
	{
		System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
	}
}
}

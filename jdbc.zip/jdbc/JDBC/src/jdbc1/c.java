package jdbc1;
import java.sql.*;
 class c {
public static void main(String h[]) throws SQLException,ClassNotFoundException {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
	CallableStatement ps=con.prepareCall("{?=call add_pro(?,?)}");
	ps.registerOutParameter(1, Types.INTEGER);
	ps.setInt(2, 11);
	ps.setInt(3, 22);
	ps.execute();
	int n=ps.getInt(1);
	System.out.println("the result is"+n);
}
}

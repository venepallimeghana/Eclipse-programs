package jdbc1;
import java.sql.*;
public class First {
public static void main(String[] args) throws Exception
{
	Class.forName("oracle.jdbc.OracleDriver");
	Connection con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
	Statement st=con.createStatement();
//st.execute("create table mphasisstudent(empno number,name varchar2(30),address varchar2(30))");
	//System.out.println("Table created");
	st.execute("insert into mphasisstudent values(101,'sandy','pune')");
	System.out.println("Row inserted");
	
	st.execute("insert into mphasisstudent values(102,'ram','chennai')");
	System.out.println("Row inserted");
	
	st.execute("insert into mphasisstudent values(103,'srav','hyd')");
	System.out.println("Row inserted");
	
	
	st.execute("update mphasisstudent set address='bangalore'where empno=101");
	System.out.println("Row updated");
	
	st.execute("delete from mphasisstudent where empno=101");
	System.out.println("Row deleted");

	
		
	ResultSet rs=st.executeQuery("select*from mphasisstudent");
	while(rs.next())
	{
		System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
	}
}
}

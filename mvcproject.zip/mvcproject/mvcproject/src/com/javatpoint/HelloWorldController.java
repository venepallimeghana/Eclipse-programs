package com.javatpoint;
import javax.servlet.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller  
public class HelloWorldController 
{  
    @RequestMapping("/hello")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res)
    {  
int a=Integer.parseInt(request.getParameter("t1"));
int b=Integer.parseInt(request.getParameter("t2"));
String e=request.getParameter("b1");
if(e.equals("ADD"))
{
	double answer=a+b;
	return new ModelAndView("hellopage","message",answer);
}
if(e.equals("SUB"))
{
	double answer=a-b;
	return new ModelAndView("hellopage ","message",answer);
}
if(e.equals("MUL"))
{
	double answer=a*b;
	return new ModelAndView("hellopage","message",answer);
}
if(e.equals("DIV"))
{
	double answer=a/b;
	return new ModelAndView("hellopage","message",answer);
}
else {
return null;

}
}}